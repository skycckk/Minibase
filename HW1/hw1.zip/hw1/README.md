## HW 1

### team members
Wei-Chung Huang: 011049791
Charles MacKay: 006702150

### What Works:
Everything should work
All test cases are passing

### Instructions to run:
1. Import eclipse project
2. Right click BMDriver.java
3. Run As: Java Application
